import './globals.css';
export const metadata={title:'Oravo AI — Your AI Marketing Team, 24/7',description:'AI-powered marketing agency SaaS for content, social media, advertising, leads and growth.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

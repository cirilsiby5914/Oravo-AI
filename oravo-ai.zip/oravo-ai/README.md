# Oravo AI

Premium AI marketing agency SaaS starter: public landing page + responsive marketing command center.

## Run locally

Requirements: Node.js 18+

```bash
npm install
npm run dev
```

Open http://localhost:3000

- `/` — public Oravo AI website
- `/dashboard` — responsive SaaS dashboard

## What is included
- Oravo AI brand system and dark premium UI
- Landing page, features, workflow and pricing sections
- Responsive dashboard with AI command center
- AI prompt interaction demo
- Content calendar preview
- Lead and analytics cards
- Automation status
- Mobile sidebar

## Production integrations to add
- Auth/database (Supabase, Clerk, Auth.js, etc.)
- OpenAI/Anthropic/Gemini API
- Meta/Instagram/Facebook OAuth and publishing APIs
- LinkedIn/TikTok/YouTube/X integrations
- Stripe subscriptions and metered AI credits
- Background jobs/queues for scheduling
- Real analytics and CRM data

The UI intentionally uses demo data until credentials and external integrations are connected.
